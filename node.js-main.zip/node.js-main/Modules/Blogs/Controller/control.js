///////////////////////////////////////////////////////////
/// <==> /// This File Contains User Functions /// <==> ///
///////////////////////////////////////////////////////////

/* ====================== /// <==> Variables Declaration <==> /// ====================== */
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { StatusCodes } = require('http-status-codes');
const {blogs} = require('../Model/model');

/* =========== /// <==> End <==> ===========*/


/* ====================== /// <==> User Functions <==> /// ====================== */

const blockBlog = async (req, res) => {
    console.log(req.params);
    
    try {
        var blogId = req.params.blogId;
        var blockedBlogId = req.body.blockedBlogId;

        await blogs.findOne({ '_id': blockedBlogId }, function (err, blockedBlog) {
            if (err) return handleError(err);
            if (blockedBlog) {
                blogs.findOne({ '_id': blogId }, 'blockedBlogs', function (err, blog) {
                    if (err) return handleError(err);
                blog.blockedBlogs.push(blockedBlogId);
                blog.save();
                res.status(StatusCodes.OK).json('Blog successfully blocked ');});
            }
            else
                res.status(StatusCodes.BAD_REQUEST).json('Blog not found ');

        }).clone().catch(function (err) { console.log(err) });


    } catch (error) {
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json('Error In blockBlog Function (<:>)');
    }
};
/* ----------- <---> Unfollow Blog <---> ----------- */ // *** <===> Done <===>  *** //

const unblockBlog = async (req, res) => {

    try {

        var blogId = req.params.blogId;
        var unblockedBlogId = req.body.unblockedBlogId;

        await blogs.findOne({ '_id': unblockedBlogId }, function (err, unblockedBlog) {
            if (err) return handleError(err);
            if (unblockedBlog) {
                blogs.findOne({ '_id': blogId }, 'blockedBlogs', function (err, blog) {
                    if (err) return handleError(err);
                blog.blockedBlogs.pull(unblockedBlogId);
                blog.save();
                res.status(StatusCodes.OK).json('Blog successfully unblocked ');});
            }
            else
                res.status(StatusCodes.BAD_REQUEST).json('Blog not found (<:>)');

        }).clone().catch(function (err) { console.log(err) });


    } catch (error) {
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json('Error In unblockBlog Function (<:>)');
    }
};


/* =========== /// <==> End <==> ===========*/

/* ====================== /// <==> Export User Functions <==> /// ====================== */

module.exports = {
    blockBlog,
    unblockBlog

};
/* =========== /// <==> End <==> ===========*/