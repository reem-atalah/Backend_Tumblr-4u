//////////////////////////////////////////////////////
/// <==> /// This File Contains User APIs /// <==> ///
//////////////////////////////////////////////////////

/* ====================== /// <==> Variables Declaration <==> /// ====================== */
const express = require('express');
const router = express.Router();
const blogFunctions = require('../Controller/control');
const blogJoi = require('../Joi/joi');
const ValidateRequest = require('../../../Common/Middlewares/requestValidation');
const isAuthorized = require('../../../Common/Middlewares/isAuthorized');
const blogEndPoints = require('../endPoints');
/* =========== /// <==> End <==> ===========*/

/* ----------- <---> Block Account <---> ----------- */ // *** <===> Done <===>  *** //
//router.patch('/user/follow/:userId', ValidateRequest(userJoi.FollowBlogValidations), isAuthorized(userEndPoints.followBlog), userFunctions.followBlog);
//router.patch('/user/unfollow/:userId', ValidateRequest(userJoi.UnfollowBlogValidations), isAuthorized(userEndPoints.unfollowBlog), userFunctions.unfollowBlog);
router.post('/blog/unblock/:blogId',blogFunctions.unblockBlog);

/* =========== /// <==> End <==> ===========*/

/* ====================== /// <==> Export User APIs <==> /// ====================== */
module.exports = router;
/* =========== /// <==> End <==> ===========*/