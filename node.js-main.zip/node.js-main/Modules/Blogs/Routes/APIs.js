//////////////////////////////////////////////////////
/// <==> /// This File Contains blog APIs /// <==> ///
//////////////////////////////////////////////////////

/* ====================== /// <==> Variables Declaration <==> /// ====================== */
const express = require('express');
const router = express.Router();
const blogFunctions = require('../Controller/control');
const blogJoi = require('../Joi/joi');
const ValidateRequest = require('../../../Common/Middlewares/requestValidation');
const isAuthorized = require('../../../Common/Middlewares/isAuthorized');
const blogEndPoints = require('../endPoints');
/* =========== /// <==> End <==> ===========*/

/* ----------- <---> Block Account <---> ----------- */ // *** <===> Done <===>  *** //
router.patch('/blog/block/:blogId', ValidateRequest(blogJoi.BlockBlogValidations), isAuthorized(blogEndPoints.blockBlog), blogFunctions.blockBlog);
router.patch('/blog/unblock/:blogId', ValidateRequest(blogJoi.UnblockBlogValidations), isAuthorized(blogEndPoints.unblockBlog), blogFunctions.unblockBlog);
//router.post('/blog/unblock/:blogId',blogFunctions.unblockBlog);


/* =========== /// <==> End <==> ===========*/

/* ====================== /// <==> Export blog APIs <==> /// ====================== */
module.exports = router;
/* =========== /// <==> End <==> ===========*/