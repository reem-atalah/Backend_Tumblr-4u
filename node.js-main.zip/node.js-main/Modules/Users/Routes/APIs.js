//////////////////////////////////////////////////////
/// <==> /// This File Contains User APIs /// <==> ///
//////////////////////////////////////////////////////

/* ====================== /// <==> Variables Declaration <==> /// ====================== */
const express = require('express');
const router = express.Router();
const userFunctions = require('../Controller/control');
const userJoi = require('../Joi/joi');
const ValidateRequest = require('../../../Common/Middlewares/requestValidation');
const isAuthorized = require('../../../Common/Middlewares/isAuthorized');
const userEndPoints = require('../endPoints');
/* =========== /// <==> End <==> ===========*/

/* ----------- <---> Block Account <---> ----------- */ // *** <===> Done <===>  *** //
router.patch('/user/follow/:userId', ValidateRequest(userJoi.FollowBlogValidations), isAuthorized(userEndPoints.followBlog), userFunctions.followBlog);
router.patch('/user/unfollow/:userId', ValidateRequest(userJoi.UnfollowBlogValidations), isAuthorized(userEndPoints.unfollowBlog), userFunctions.unfollowBlog);
//router.post('/user/unfollow/:userId',userFunctions.unfollowBlog);

/* =========== /// <==> End <==> ===========*/

/* ====================== /// <==> Export User APIs <==> /// ====================== */
module.exports = router;
/* =========== /// <==> End <==> ===========*/