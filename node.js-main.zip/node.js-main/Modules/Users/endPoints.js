////////////////////////////////////////////////////////////////
//// <==> This File Contains All User Module EndPoints <==> ////
////////////////////////////////////////////////////////////////

/* ======================== <-- User Modul EndPoints --> ======================== */
const Update_Profile = 'User:Update_Profile';
const Update_Password = 'User:Update_Password';
const Deactivate = 'User:Deactivate';
const Activate = 'User:Activate';
const Get_All_Users = 'User:Get_All_Users';
const Add_Admin = 'User:Add_Admin';
const Get_All_Admins = 'User:Get_All_Admins';
const Delete_Admin = 'User:Delete_Admin';
const Block_User = 'User:Block_User';

const userEndPoints = {
    Update_Profile,
    Update_Password,
    Deactivate,
    Activate,
    Get_All_Users,
    Add_Admin,
    Get_All_Admins,
    Delete_Admin,
    Block_User
};
/* =========== <--> End <--> =========== */

/* ======================== <-- Export User EndPoints --> ======================== */
module.exports = userEndPoints;
/* =========== <--> End <--> =========== */