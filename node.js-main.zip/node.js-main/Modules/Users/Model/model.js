///////////////////////////////////////////////////////////
/// <==> /// This File Creates User Collection /// <==> ///
///////////////////////////////////////////////////////////

/* ====================== /// <==> Variables Declaration <==> /// ====================== */
const mongoose = require('mongoose');
const {userSchema} = require('../Schema/schema');
const {blogSchema} = require('../Schema/schema');
/* =========== /// <==> End <==> ===========*/

/* ====================== /// <==> Create User Model <==> /// ====================== */
const users = mongoose.model('users', userSchema);

const blogs = mongoose.model('blogs', blogSchema);

/* =========== /// <==> End <==> ===========*/

/* ====================== /// <==> Export User Model <==> /// ====================== */
module.exports = {users,blogs};


/* =========== /// <==> End <==> ===========*/