///////////////////////////////////////////////////////////
/// <==> /// This File Contains User Functions /// <==> ///
///////////////////////////////////////////////////////////

/* ====================== /// <==> Variables Declaration <==> /// ====================== */
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { StatusCodes } = require('http-status-codes');
const {users} = require('../Model/model');
const {blogs}= require('../../Blogs/Model/model');
/* =========== /// <==> End <==> ===========*/

/* ====================== /// <==> User Functions <==> /// ====================== */

              
const followBlog = async (req, res) => {
    console.log(req.params);
  try {
        var userId = req.params.userId;
        var blogId = req.body.blogId;
        console.log(userId);
        await blogs.findOne({ '_id': blogId }, 'followers', function (err, blog) {
            if (err) return handleError(err);
            if (blog) {
                blog.followers.push(userId);
                blog.save();
                users.findOne({ '_id': userId }, 'following_blogs', function (err, user) {
                    if (err) return handleError(err);
                    user.following_blogs.push(blogId);
                    user.save();
                });
                res.status(StatusCodes.OK).json('Blog successfully followed (<:>)');
            }
            else
                res.status(StatusCodes.BAD_REQUEST).json('Blog not found (<:>)');

        }).clone().catch(function(err){ console.log(err)});


    } catch (error) {
      res.status(StatusCodes.INTERNAL_SERVER_ERROR).json('Error In followBlog Function (<:>)');
    }
};
/* ----------- <---> Unfollow Blog <---> ----------- */ // *** <===> Done <===>  *** //

const unfollowBlog = async (req, res) => {
   
    try {
   
        var userId = req.params.userId;
        var blogId = req.body.blogId;
        await blogs.findOne({ '_id': blogId }, 'followers', function (err, blog) {
            if (err) return handleError(err);
            if (blog) {

                blog.followers.pull( userId );
                blog.save();
                users.findOne({ '_id': userId }, 'following_blogs', function (err, user) {
                    if (err) return handleError(err);
                    user.following_blogs.pull(blogId);
                    user.save();
                });
                res.status(StatusCodes.OK).json('Blog successfully unfollowed (<:>)');
            }
        
            else
                res.status(StatusCodes.BAD_REQUEST).json('Blog not found (<:>)');

        }).clone().catch(function(err){ console.log(err)});;


   } catch (error) {
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json('Error In unfollowBlog Function (<:>)');
    }
};


/* =========== /// <==> End <==> ===========*/

/* ====================== /// <==> Export User Functions <==> /// ====================== */

module.exports = {
    followBlog,
    unfollowBlog
 
};
/* =========== /// <==> End <==> ===========*/