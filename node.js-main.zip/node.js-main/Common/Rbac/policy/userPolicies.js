/////////////////////////////////////////////////////////////
//// <==> This File Contains All User Role Policies <==> ////
/////////////////////////////////////////////////////////////

/* ======================== <-- Variables Declarations --> ======================== */
const userEndPoints = require('../../../Modules/Users/endPoints');
/*const postEndPoints = require('../../../Modules/Posts/endPoints');
const reportEndPoints = require('../../../Modules/Report/endPoints');
const advertisingEndPoints = require('../../../Modules/Advertising/endPoints');*/

/* =========== <--> End <--> =========== */

/* ======================== <-- User Role Policies --> ======================== */
const userPolicies = [userEndPoints.followBlog,
    userEndPoints.unfollowBlog
];
/* =========== <--> End <--> =========== */

/* ======================== <-- Export User Role Policies --> ======================== */
module.exports = userPolicies;
/* =========== <--> End <--> =========== */